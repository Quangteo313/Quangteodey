// var course = {
//   name: "JavaScript",
//   cost: 0,
// };
// // if (course.cost > 0) {
// //   console.log(`${course.cost} Coins`);
// // } else {
// //   console.log("Free");
// // }
// //or
// var result = course.cost > 0 ? `${course.cost} Coins` : "Free";
// console.log(result);
// //3 Ngoi
// Làm bài
function getCanVoteMessage(age) {
  var result = age >= 18 ? "Bạn có thể bỏ phiếu" : "Bạn chưa được bỏ phiếu";
  return result;
}
// Kỳ vọng
console.log(getCanVoteMessage(18)); // 'Bạn có thể bỏ phiếu'
console.log(getCanVoteMessage(15)); // 'Bạn chưa được bỏ phiếu'
