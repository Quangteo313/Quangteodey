/*
Array methods: 
             forEach()
             every()
             some()
             find()
             filter()
             map()
             reduce()
*/
var courses = [
  {
    id: 1,
    name: "JavaScript",
    coin: 250,
  },
  {
    id: 2,
    name: "HTML , Css",
    coin: 0,
  },
  {
    id: 3,
    name: "Ruby",
    coin: 0,
  },
  {
    id: 4,
    name: "PHP",
    coin: 1000,
  },
];
// Xét từng Object trong mảng
courses.forEach(function (courses, index) {
  console.log(index, courses); // callback
});
// kiểm tra tất cả có coin = 0 không ?
var isFree = courses.every(function (courses, index) {
  console.coin === 0; // callback
});
console.log(isFree);
// kiểm tra 1 trong tất cả có coin = 0 là được ( trả về true)
var isFreeTwo = courses.some(function (courses, index) {
  return courses.coin === 0; // callback
});
console.log(isFreeTwo);
//Tìm Kiếm
var findName = courses.find(function (courses) {
  return courses.name === "JavaScript"; // callback
});
console.log(findName);
//Tìm kiếm trả về nhiều phần tử thỏa mãn yêu cầu filter
