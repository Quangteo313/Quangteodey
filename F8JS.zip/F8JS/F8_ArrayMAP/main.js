var courses = [
  {
    id: 1,
    name: "JavaScript",
    coin: 250,
  },
  {
    id: 2,
    name: "HTML , Css",
    coin: 0,
  },
  {
    id: 3,
    name: "Ruby",
    coin: 0,
  },
  {
    id: 4,
    name: "PHP",
    coin: 1000,
  },
];
function coursesHandler(courses) {
  return {
    id: courses.id,
    name: `Khoa Hoc : ${courses.name} `,
    coin: courses.coin,
    coinText: `Gia ${courses.coin}`,
  };
}
var newCourses = courses.map(coursesHandler);
console.log(newCourses);
