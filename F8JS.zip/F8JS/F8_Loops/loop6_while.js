// var i = 0;
// while (i < 1000) {
//   i++;
//   console.log(i);
// }
var myArray = ["JavaScript", "PHP"];
var i = 0;
while (i < myArray.length) {
  console.log(myArray[i]);
  i++;
}
