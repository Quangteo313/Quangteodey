/* 
Vòng lặp - loop
    1- For - lặp với điều kiện đúng 
    2- for-in : lặp qua key của đối tượng
    3- for-of : lặp qua value của đối tượng
    4-while : lặp khi điều kiện đúng 
    5-do-while : lặp ít nhất 1 lần sau đó lặp khi điều kiện đúng 
*/
//For loop
// for (var i = 1; i <= 1000; i++) {
//   console.log("Anh yeu em lan: " + i);
// }
// Làm bài
function getRandNumbers(min, max, length) {
  var result = 0;
  var arr = [];

  for (var i = 0; i < length; i++) {
    result = Math.random() * (max - min) + min;
    arr.push(result);
  }
  return arr;
}
getRandNumbers(0, 5, 6);

/**
 * Hết sức lưu ý: Hãy suy nghĩ kỹ để đảm bảo vòng lặp (loop)
 * luôn có điểm dừng, trình duyệt của bạn sẽ bị treo
 * nếu vòng lặp không có điểm dừng.
 *
 * VD 1: for (var i = 0; i < 100; i--) // i++ mới đúng
 * VD 2: for (var i = 100; i >= 0; i++) // i-- mới đúng
 * là 2 vòng lặp không có điểm dừng (lặp vô hạn)
 *
 * => Treo trình duyệt!!!
 */
