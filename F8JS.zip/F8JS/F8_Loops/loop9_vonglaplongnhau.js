var myArray = [
  [1, 2],
  [4, 5],
  [6, 7],
];
for (let i = 0; i < myArray.length; i++) {
  for (let j = 0; j < myArray[i].length; j++) {
    console.log(myArray[i][j]);
  }
}
