function getTotal(arr) {
  var results = 0;
  for (var i = 0; i < arr.length; i++) {
    results += arr[i];
  }
  return results;
}
getTotal([1, 2, 3]);
console.log(results);
// Expected results
// Output: 6

//getTotal([4, 5, -3]); // Output: 6
//getTotal([4, 5, 3, 5]); // Output: 17
