// var language = ["Javascript", "PHP", "Java"];
// for (var value of language) {
//   console.log(value);
// } // cách lấy phần tử của array
//cách lấy phần tử ra khỏi Object
var myInfo = {
  name: "Thanh Quang",
  age: 20,
};
for (var value of Object.values(myInfo)) {
  console.log(value);
}
