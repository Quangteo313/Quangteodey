var i = 0;
var isSuccess = false;

do {
  i++;
  console.log("Nap the lan 1" + i);
  if (true) {
    isSuccess = true;
  }
} while (!isSuccess && i <= 3);
