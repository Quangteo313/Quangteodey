var a = 6;
var b = 5;
if (a > b) {
  document.write("true");
} else {
  document.write("false");
}
