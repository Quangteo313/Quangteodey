/**
 * Giới thiệu về toán tử trong javascript
 * 1. Toán tử số học - arithmetic
 * 2.Toán tử gán - assignment
 * 3. Toán tử so sánh - Comparison
 * 4. Toán tử logic - logical
 */
var a = 1 + 2;
console.log(a);
var b = 1;
var c = 2;
if (b > c) {
  alert("True");
} else {
  alert("False");
}
