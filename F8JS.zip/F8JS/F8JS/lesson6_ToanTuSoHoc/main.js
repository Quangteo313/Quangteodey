/**
 *  + --> Cộng
 *  - --> Trừ
 *  * --> Nhân
 *  ** --> Lũy Thừa
 *  / --> Chia
 *  % --> Chia lấy số dư
 *  ++ --> Tăng 1 giá trị số
 *  -- --> Giảm 1 giá trị số
 */
var a = 2;
a++;
document.write(a);
