/**
 * Kiểu dữ liệu trong JavaScript
 * 1- Dữ liệu nguyên thủy - Primitive Data
 * -Number
 * -String
 * -Boolean
 * -Undefined
 * -Null
 * -Symbol
 * 2-Kiểu dữ liệu phức tạp
 * -Function
 * -Object
 */
//Number type
var a = 1;
var b = 5;
// String type
var fullName = "Dao Thanh Quang";
console.log(fullName);
// boolean type
var isSuccess = true;
// Undefined type
var age;
// null type
var isNull = null; // k co gi ca
//Symbol
var id = Symbol("id"); // unique
// Function
var myFunction = function () {
  alert("Hi.Xin Chao cac ban!");
};
myFunction();
//Object type
var myObject = {
  name: "Thanh Quang",
  age: 20,
  school: "NDH highschool",
  address: "hanoi",
};

var myArray = ["JavaScript", "PHP", "Java"];
