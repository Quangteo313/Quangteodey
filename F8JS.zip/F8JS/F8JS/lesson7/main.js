/**
 * ++a
 * Việc 1 : +1 cho a , a = a +1
 * Việc 2 : Trả về sau khi được cộng 1
 * a++
 *Việc 1 : a copy , a copy vẫn bằng a
 *Việc 2 : Cộng 1 của a , a = a + 1
 *Việc 3 : Trả về biến a copy
 */
var number = 6;
var output = number++ + --number;
// 6 + 6 = 12
console.log(output);
