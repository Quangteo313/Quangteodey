// Comments trong JS
// Sử dụng phím tắt : Ctrl + /
var fullName = "Dao Thanh Quang"; // khai bao ten
var age = 20; // khai bao tuoi
