var trangthai = "doi";
if (trangthai == "doi") {
  console.log("an");
} else {
  console.log("Nhin");
}
