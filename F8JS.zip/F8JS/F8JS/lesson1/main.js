alert("Hi JavaScript Basic");
