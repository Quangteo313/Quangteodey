/*
Giới thiệu một số hàm built - in
    1 . Alert
    2 . Console
    3 . Confirm
    4 . Prompt
    5 . Set timeout
    6 . Set interval
*/

// console.log("Day la thong bao log");
// var fullName = "Dao Thanh Quang";
// console.log(fullName);

// confirm("Xac nhan ban du tuoi!");
// prompt("Nhap so tuoi cua b");
// setTimeout(function () {
//   alert("Thong bao");
// }, 1000);
setInterval(function () {
  alert("Ngu vl");
}, 1000);
