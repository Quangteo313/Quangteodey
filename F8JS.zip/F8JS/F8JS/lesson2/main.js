var fullName = "Dao Thanh Quang";
var age = 26;
alert(age);
alert(fullName);
