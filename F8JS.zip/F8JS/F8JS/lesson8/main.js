/**
 * Toán tử      Ví Dụ       Tương đương
 * =            x = y          x = y
 * +=           x += y         x = x + y
 * -=           x -= y         x = x - y
 * *=           x *= y         x = x * y
 * /=           x /= y         x = x / y
 * **=          x **= y        x = x ** y
 */
var a = 5;
var b = 6;
console.log((a **= b));
