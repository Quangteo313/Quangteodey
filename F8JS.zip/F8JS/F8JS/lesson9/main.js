var firstName = "Dao";
var lastName = "Quang";
document.write(firstName + " " + lastName);
